import { Category, Product, PaymentMethod, PartnerConfig, Coupon } from '../types';

export const INITIAL_CATEGORIES: Category[] = [
  {
    id: "bots",
    ty: "shop",
    i: "bot",
    ar: "روبوتات وخوارزميات",
    en: "Trading Bots & Algos",
    da: "خوارزميات تداول آلية لأقوى منصات التداول",
    de: "Automated trading bots and algorithmic systems",
    f: [
      { ar: "المنصة", en: "Platform", o: ["MetaTrader 5", "MetaTrader 4", "TradingView Pine", "cTrader"] },
      { ar: "السوق", en: "Market", o: ["الذهب XAUUSD", "المؤشرات US30/NAS100", "العملات Forex", "الكريبتو Crypto"] }
    ]
  },
  {
    id: "boost",
    ty: "boost",
    i: "trend",
    ar: "زيادة متابعين ورشق",
    en: "Followers & Boost",
    da: "خدمات زيادة المتابعين والتفاعل الحقيقي لجميع المنصات",
    de: "High retention followers and social media engagement services",
    f: [
      { ar: "المنصة", en: "Platform", o: ["Instagram", "TikTok", "YouTube", "Telegram", "X"] },
      { ar: "نوع الخدمة", en: "Service", o: ["متابعين", "لايكات", "مشاهدات", "تعليقات"] }
    ]
  },
  {
    id: "games",
    ty: "hub",
    hub: "games",
    i: "bolt",
    ar: "شحن الألعاب",
    en: "Game Top-up",
    da: "اشحن شدات وجواهر ألعابك المفضلة فورياً وبأفضل سعر",
    de: "Top-up game credits, UC, diamonds and gift cards instantly",
    f: [
      { ar: "اللعبة", en: "Game", o: ["PUBG Mobile", "Free Fire", "EA FC Mobile", "Roblox", "Call of Duty"] }
    ]
  },
  {
    id: "apps_hub",
    ty: "hub",
    hub: "apps",
    i: "users",
    ar: "تطبيقات واشتراكات",
    en: "Apps & Subscriptions",
    da: "عملات تطبيقات البث والدردشة واشتراكات الذكاء الاصطناعي",
    de: "Coins for live & chat apps, AI subscriptions and creative tools",
    f: [
      { ar: "النوع", en: "Type", o: ["بث مباشر", "ذكاء اصطناعي", "تصميم وإنتاجية"] }
    ]
  },
  {
    id: "websites",
    ty: "shop",
    i: "globe",
    ar: "مواقع ومنصات",
    en: "Websites & Platforms",
    da: "منصات ويب جاهزة ومشاريع SaaS تجارية متكاملة",
    de: "Turnkey web platforms, SaaS starters and enterprise stores",
    f: [
      { ar: "مجال المنصة", en: "Industry", o: ["تجارة إلكترونية", "SaaS اشتراكات", "بورتفوليو ووكالات", "حجوزات واستشارات"] },
      { ar: "قاعدة البيانات", en: "Backend", o: ["PostgreSQL", "Supabase", "Firebase", "MongoDB"] }
    ]
  },
  {
    id: "apps",
    ty: "shop",
    i: "phone",
    ar: "تطبيقات وبرمجيات",
    en: "Apps & Software",
    da: "تطبيقات جوال ولوحات تحكم قابلة للإطلاق المباشر",
    de: "Mobile apps and production-ready cross-platform dashboards",
    f: [
      { ar: "التقنية", en: "Tech Stack", o: ["Flutter", "Jetpack Compose", "React Native", "Next.js"] },
      { ar: "نوع التطبيق", en: "App Type", o: ["توصيل ومتاجر", "محفظة مالية", "لوحة تحكم CRM", "دردشة ومراسلة"] }
    ]
  },
  {
    id: "numbers",
    ty: "numbers",
    i: "phone",
    ar: "أرقام للتفعيل",
    en: "Virtual Numbers",
    da: "أرقام خاصة لاستقبال كود التفعيل لجميع البرامج",
    de: "Private virtual phone numbers to receive verification SMS",
    f: [
      { ar: "الخدمة", en: "Service", o: ["WhatsApp", "Telegram", "Facebook", "Instagram", "TikTok", "ChatGPT", "Google"] },
      { ar: "الدولة", en: "Country", o: ["أمريكا", "بريطانيا", "كندا", "إندونيسيا", "هولندا", "فرنسا"] }
    ]
  },
  {
    id: "funded",
    ty: "funded",
    i: "bank",
    ar: "شراء حسابات ممولة",
    en: "Funded Accounts",
    da: "حسابات تداول ممولة بدون قيود لتكبير رأس المال",
    de: "Funded trading accounts with evaluation challenges & profit share",
    f: []
  },
  {
    id: "bonus",
    ty: "embed",
    i: "gift",
    ar: "البونصات المجانية",
    en: "Free Bonuses",
    da: "بونصات وهدايا حصرية بدون إيداع للمتداولين",
    de: "Exclusive deposit and no-deposit trading bonuses",
    f: []
  }
];

export const INITIAL_PRODUCTS: Product[] = [
  // Bots
  {
    id: "bot_scalper_01",
    c: "bots",
    ar: "روبوت التداول الآلي AMARIX Trend Scalper Pro (MT5)",
    en: "AMARIX Trend Scalper Pro Trading Bot (MT5)",
    p: 890,
    o: 1450,
    r: 4.95,
    n: 247,
    bs: 1,
    d: 38,
    tg: "MetaTrader 5 الذهب XAUUSD العملات Forex",
    sp: "MT5 · Gold & Forex",
    description_ar: "خوارزمية ذكية متطورة لمنصة MT5 تعتمد على كسر مناطق السيولة ونسب فيبوناتشي مع نظام إدارة مخاطر صارم ومؤشرات تتبع وقف الخسارة المتحرك.",
    description_en: "Advanced algorithmic trading system for MT5 focusing on liquidity sweep & order blocks with strict automated risk management.",
    specs: "MetaTrader 5 | Timeframes: M5-M15 | Drawdown < 6%"
  },
  {
    id: "bot_gold_hunter",
    c: "bots",
    ar: "خوارزمية صائد الذهب AMARIX Gold Hunter EA (MT4/MT5)",
    en: "AMARIX Gold Hunter High-Frequency EA",
    p: 650,
    o: 990,
    r: 4.88,
    n: 184,
    bs: 2,
    d: 34,
    tg: "MetaTrader 5 الذهب XAUUSD",
    sp: "MT4/MT5 · XAUUSD Specialist",
    description_ar: "روبوت مصمم خصيصاً للتداول اليومي على الذهب XAUUSD في جلسات لندن ونيويورك متوافق تماماً مع حسابات التمويل.",
    description_en: "Prop-firm ready EA specialized in Gold XAUUSD day trading during London and New York overlaps.",
    specs: "Prop Firm Pass Ready | No Martingale | Fixed Stop Loss"
  },
  {
    id: "bot_crypto_arb",
    c: "bots",
    ar: "بوت تداول العملات الرقمية AMARIX Crypto Arbitrage Multi-Exchange",
    en: "AMARIX Crypto Arbitrage & Market Maker Bot",
    p: 1200,
    o: 1800,
    r: 4.9,
    n: 98,
    bs: 4,
    d: 33,
    tg: "الكريبتو Crypto cTrader",
    sp: "Binance & Bybit API",
    description_ar: "نظام مالي آلي يرصد فروقات الأسعار اللحظية بين كبرى منصات تداول الكريبتو وينفذ الأوامر في أجزاء من الثانية بدون مخاطر اتجاهية.",
    description_en: "Low latency arbitrage and liquidity maker engine for major crypto spot & perp markets.",
    specs: "WebSockets Execution | Latency < 15ms | Multi-exchange"
  },

  // SMM Boost
  {
    id: "boost_ig_followers_1k",
    c: "boost",
    ar: "زيادة 1,000 متابع إنستغرام (حسابات حقيقية + ضمان)",
    en: "Instagram 1,000 Followers (High Quality + Refill)",
    p: 4.5,
    o: 8.0,
    r: 4.9,
    n: 520,
    bs: 1,
    d: 44,
    tg: "Instagram متابعين",
    sp: "Instagram · 1,000",
    smm_provider: "main",
    smm_service: 101,
    smm_qty: 1000,
    smm_input: "link",
    description_ar: "متابعون بجودة ممتازة مع صور شخصية ومنشورات، سرعة وصول سريعة وضمان تعويض تلقائي لمدة 30 يوماً.",
    description_en: "High retention real looking followers with profile pictures, stable delivery, 30 days refill guarantee."
  },
  {
    id: "boost_tiktok_views_10k",
    c: "boost",
    ar: "زيادة 10,000 مشاهدة تيك توك لدخول الإكسبلور",
    en: "TikTok 10,000 For You Page Views Boost",
    p: 2.0,
    o: 4.5,
    r: 4.95,
    n: 610,
    bs: 3,
    d: 55,
    tg: "TikTok مشاهدات",
    sp: "TikTok · 10,000 Views",
    smm_provider: "main",
    smm_service: 204,
    smm_qty: 10000,
    smm_input: "link",
    description_ar: "مشاهدات فائقة السرعة ترفع التفاعل وتدعم وصول الفيديو إلى صفحة For You بنسب تفاعل عالية.",
    description_en: "Super fast TikTok views delivering algorithmic signals to trigger For You recommendation reach."
  },
  {
    id: "boost_tg_members_1k",
    c: "boost",
    ar: "زيادة 1,000 عضو قناة/مجموعة تليجرام بدون نقص",
    en: "Telegram 1,000 Channel Members (Non-Drop)",
    p: 5.5,
    o: 9.0,
    r: 4.85,
    n: 340,
    bs: 5,
    d: 38,
    tg: "Telegram متابعين",
    sp: "Telegram · 1,000 Members",
    smm_provider: "main",
    smm_service: 312,
    smm_qty: 1000,
    smm_input: "link",
    description_ar: "أعضاء قنوات ومجموعات تليجرام ثابتين، يدعمون القنوات العامة والخاصة فورياً.",
    description_en: "Stable Telegram channel and group subscribers for public and invite-only links."
  },
  {
    id: "boost_yt_subs_500",
    c: "boost",
    ar: "زيادة 500 مشترك يوتيوب حقيقي لتحقيق شروط الدخل",
    en: "YouTube 500 Real Subscribers (Monetization Safe)",
    p: 18.0,
    o: 28.0,
    r: 4.92,
    n: 215,
    bs: 6,
    d: 35,
    tg: "YouTube متابعين",
    sp: "YouTube · 500 Subs",
    smm_provider: "main",
    smm_service: 405,
    smm_qty: 500,
    smm_input: "link",
    description_ar: "مشتركون آمنون متوافقون تماماً مع شروط برنامج شركاء يوتيوب لتحقيق الربح.",
    description_en: "Safe subscribers complying with YouTube partner program terms for channel monetization."
  },

  // Game Top-ups
  {
    id: "game_pubg_660_uc",
    c: "games",
    ar: "شحن 660 شدة ببجي موبايل (PUBG Mobile 660 UC)",
    en: "PUBG Mobile 660 UC Direct Top-up",
    p: 9.8,
    o: 12.0,
    r: 4.98,
    n: 1420,
    bs: 1,
    d: 18,
    tg: "PUBG Mobile شدات",
    sp: "PUBG UC · Global ID",
    ptype: "game_topup",
    smm_provider: "main",
    smm_service: "pubg_660",
    smm_input: "link",
    description_ar: "شحن شدات ببجي موبايل عبر معرّف اللاعب (Player ID) مباشرة خلال 1 إلى 5 دقائق.",
    description_en: "Instant PUBG Mobile UC top-up via direct Player ID without logging into your account."
  },
  {
    id: "game_pubg_1800_uc",
    c: "games",
    ar: "شحن 1,800 شدة ببجي موبايل (PUBG Mobile 1,800 UC)",
    en: "PUBG Mobile 1,800 UC Direct Top-up",
    p: 24.5,
    o: 30.0,
    r: 4.97,
    n: 890,
    bs: 2,
    d: 18,
    tg: "PUBG Mobile شدات",
    sp: "PUBG UC · Global ID",
    ptype: "game_topup",
    smm_provider: "main",
    smm_service: "pubg_1800",
    smm_input: "link",
    description_ar: "الباقة الأكثر طلباً لشراء الرويال باس وترقية الأسلحة القابلة للتطوير.",
    description_en: "Most popular UC package for Royale Pass purchase and weapon upgrades."
  },
  {
    id: "game_freefire_1080_diamonds",
    c: "games",
    ar: "شحن 1,080 جوهرة فري فاير (Free Fire 1080 Diamonds)",
    en: "Free Fire 1,080 Diamonds Instant Top-up",
    p: 10.5,
    o: 13.5,
    r: 4.94,
    n: 740,
    bs: 4,
    d: 22,
    tg: "Free Fire جواهر",
    sp: "Free Fire · Player ID",
    ptype: "game_topup",
    smm_input: "link",
    description_ar: "شحن جواهر لعبة فري فاير فورياً بالآي دي الرسمي للاعب.",
    description_en: "Direct Free Fire diamond top-up via official Player ID."
  },
  {
    id: "game_eafc_fc_points_1050",
    c: "games",
    ar: "شحن 1,050 نقطة فيفا FC Points (EA Sports FC Mobile)",
    en: "EA Sports FC Mobile 1,050 FC Points",
    p: 11.0,
    o: 14.0,
    r: 4.9,
    n: 430,
    bs: 7,
    d: 21,
    tg: "EA FC Mobile نقاط",
    sp: "EA FC · UID",
    ptype: "game_topup",
    smm_input: "link",
    description_ar: "شحن نقاط فيفا FC Mobile لفتح بكجات وتشكيلات اللاعبين الأساطير.",
    description_en: "Instant EA FC points to open packs and enhance your ultimate team."
  },

  // Apps & Subscriptions
  {
    id: "app_chatgpt_plus_1m",
    c: "apps_hub",
    ar: "اشتراك شات جي بي تي بلس (ChatGPT Plus 1 Month)",
    en: "ChatGPT Plus 1 Month Private Subscription",
    p: 21.5,
    o: 25.0,
    r: 4.96,
    n: 680,
    bs: 1,
    d: 14,
    tg: "ذكاء اصطناعي ChatGPT",
    sp: "ChatGPT Plus · GPT-4o",
    ptype: "app_subscription",
    description_ar: "حساب خاص أو تفعيل على بريدك الخاص للوصول الكامل إلى GPT-4o وo1 ومولد الصور DALL-E بلا حدود.",
    description_en: "Private 1-month ChatGPT Plus account with full access to GPT-4o, o1 models and code interpreter."
  },
  {
    id: "app_canva_pro_1y",
    c: "apps_hub",
    ar: "اشتراك كانفا برو لمدة سنة كاملة (Canva Pro 1 Year)",
    en: "Canva Pro 1 Year Official Team Invite",
    p: 12.0,
    o: 45.0,
    r: 4.98,
    n: 1120,
    bs: 2,
    d: 73,
    tg: "تصميم وإنتاجية Canva",
    sp: "Canva Pro · 12 Months",
    ptype: "app_subscription",
    description_ar: "تفعيل كانفا برو على بريدك الإلكتروني الشخصي لمدة 365 يوماً مع كافة القوالب والذكاء الاصطناعي وإزالة الخلفيات.",
    description_en: "Upgrade your own email to Canva Pro for 1 full year with all premium templates and AI tools."
  },
  {
    id: "app_tiktok_coins_700",
    c: "apps_hub",
    ar: "شحن 700 عملة تيك توك للبث المباشر (TikTok Coins)",
    en: "TikTok 700 Coins Live Top-up",
    p: 9.5,
    o: 12.0,
    r: 4.92,
    n: 530,
    bs: 5,
    d: 20,
    tg: "بث مباشر TikTok",
    sp: "TikTok · 700 Coins",
    ptype: "app_subscription",
    smm_input: "link",
    description_ar: "عملات تيك توك رسمية لإرسال الهدايا ودعم منشئي المحتوى في البث المباشر.",
    description_en: "Official TikTok coins to send gifts and support creators during live streams."
  },

  // Websites & Platforms
  {
    id: "site_saas_crm_portal",
    c: "websites",
    ar: "منصة ويب تجارية جاهزة لإدارة المتاجر والعملاء SaaS CRM",
    en: "Turnkey Multi-Tenant SaaS CRM Platform (React + Supabase)",
    p: 750,
    o: 1300,
    r: 4.96,
    n: 84,
    bs: 2,
    d: 42,
    tg: "SaaS اشتراكات Supabase PostgreSQL",
    sp: "Full-Stack SaaS · React + Node",
    description_ar: "كود كامل قابل للنشر الفوري لمنصة SaaS سحابية تتضمن إدارة الاشتراكات، المحافظ، بوابات الدفع، وإدارة المستخدمين مع لوحة تحكم إدارية شاملة.",
    description_en: "Complete multi-tenant SaaS application with stripe/crypto billing, user roles, notifications, and analytics dashboard.",
    specs: "React 19 + TypeScript | Supabase Auth & DB | Tailwind CSS | Full Source Code"
  },
  {
    id: "site_ecom_digital",
    c: "websites",
    ar: "متجر بيع منتجات رقمية متكامل مع نظام دفع آلي ومحفظة",
    en: "Digital Goods E-commerce Store with Automated Delivery",
    p: 580,
    o: 950,
    r: 4.91,
    n: 63,
    bs: 4,
    d: 38,
    tg: "تجارة إلكترونية PostgreSQL",
    sp: "Digital Goods · Instant Key Delivery",
    description_ar: "نظام متجر فائق السرعة مخصص لبيع البطاقات الرقمية، الشدات، البرمجيات مع تسليم فوري للأكواد وتتبع الطلبات.",
    description_en: "Turnkey digital storefront with automated stock delivery, customer ticket desk, and invoice generator.",
    specs: "Bilingual AR/EN | Wallet System | Telegram Alerts"
  },

  // Apps
  {
    id: "app_crypto_wallet_flutter",
    c: "apps",
    ar: "تطبيق محفظة عملات رقمية Web3 متعدد السلاسل (Flutter)",
    en: "Multi-Chain Web3 Crypto Wallet Mobile App (Flutter)",
    p: 980,
    o: 1600,
    r: 4.93,
    n: 52,
    bs: 3,
    d: 38,
    tg: "Flutter محفظة مالية",
    sp: "Flutter · iOS & Android",
    description_ar: "تطبيق موبايل هجين يدعم شبكات EVM وترون وسولانا مع حفظ الكلمات المفتاحية بأعلى معايير التشفير العسكري.",
    description_en: "Production Flutter iOS/Android crypto wallet with biometric auth, swap integration and push alerts.",
    specs: "BIP39 Seedphrase | Biometric Security | WalletConnect v2"
  },
  {
    id: "app_delivery_marketplace",
    c: "apps",
    ar: "تطبيق توصيل طلبات ومتاجر متكامل مع تتبع مباشر للخرائط",
    en: "On-Demand Delivery & Courier App (React Native)",
    p: 850,
    o: 1400,
    r: 4.89,
    n: 41,
    bs: 6,
    d: 39,
    tg: "React Native توصيل ومتاجر",
    sp: "React Native · Live GPS",
    description_ar: "منظومة 3 تطبيقات (تطبيق العميل + تطبيق السائق + لوحة تحكم المتجر) مع إشعارات دفع وتتبع لحظي على الخريطة.",
    description_en: "Complete delivery ecosystem (Customer app + Driver app + Admin dispatch panel) with live GPS routing.",
    specs: "React Native + Expo | Node backend | Google Maps GPS"
  },

  // Virtual Numbers
  {
    id: "num_wa_us_1",
    c: "numbers",
    ar: "رقم واتساب أمريكي لتفعيل الحساب (تفعيل خاص مرة واحدة)",
    en: "WhatsApp USA Number (Private Verification)",
    p: 1.5,
    o: 3.0,
    r: 4.97,
    n: 1840,
    bs: 1,
    d: 50,
    tg: "WhatsApp أمريكا",
    sp: "WhatsApp · USA (+1)",
    smm_country: "0",
    smm_service: "wa",
    smm_provider: "smsactivate",
    smm_input: "none",
    description_ar: "رقم هاتف حقيقي خاص غير مكرر لاستلام رمز تفعيل الواتساب فورياً خلال ثوانٍ.",
    description_en: "Private dedicated US phone number to receive WhatsApp OTP code instantly."
  },
  {
    id: "num_tg_uk_1",
    c: "numbers",
    ar: "رقم تليجرام بريطاني لتفعيل الحساب الشخصي (+44)",
    en: "Telegram UK Number (Private Verification)",
    p: 1.8,
    o: 3.5,
    r: 4.94,
    n: 1320,
    bs: 2,
    d: 48,
    tg: "Telegram بريطانيا",
    sp: "Telegram · UK (+44)",
    smm_country: "16",
    smm_service: "tg",
    smm_provider: "smsactivate",
    smm_input: "none",
    description_ar: "رقم بريطاني لاستقبال كود التحقق من تليجرام دون كشف هويتك أو رقمك الحقيقي.",
    description_en: "Dedicated United Kingdom number to verify your Telegram account safely."
  },
  {
    id: "num_chatgpt_fr_1",
    c: "numbers",
    ar: "رقم فرنسي لتفعيل حساب OpenAI / ChatGPT (+33)",
    en: "OpenAI / ChatGPT France Number Verification",
    p: 1.6,
    o: 3.2,
    r: 4.91,
    n: 640,
    bs: 3,
    d: 50,
    tg: "ChatGPT فرنسا",
    sp: "OpenAI · France (+33)",
    smm_country: "78",
    smm_service: "oi",
    smm_provider: "smsactivate",
    smm_input: "none",
    description_ar: "رقم لتفعيل حسابات الذكاء الاصطناعي OpenAI وChatGPT للدول المحظورة.",
    description_en: "France virtual phone number to activate OpenAI accounts in restricted regions."
  },

  // Funded Accounts
  {
    id: "funded_100k_account",
    c: "funded",
    ar: "حساب ممول 100,000$ (تقييم خطوتين بنسبة ربح 85%)",
    en: "100K Funded Challenge Account (85% Profit Split)",
    p: 490,
    o: 650,
    r: 4.96,
    n: 120,
    bs: 1,
    d: 24,
    tg: "MT5 حساب ممول",
    sp: "100,000$ Balance · No Time Limit",
    description_ar: "حساب تحدي تداول ممول برأس مال 100 ألف دولار بدون حد زمني لإنجاز الهدف مع ميزة السحب الأسبوعي وتقسيم أرباح يصل إلى 85%.",
    description_en: "100K capital evaluation account with no time limit, weekly payouts, and up to 85% profit split."
  },
  {
    id: "funded_50k_account",
    c: "funded",
    ar: "حساب ممول 50,000$ (تقييم مرحلة واحدة سريعة)",
    en: "50K 1-Phase Rapid Funded Account",
    p: 290,
    o: 390,
    r: 4.92,
    n: 95,
    bs: 2,
    d: 25,
    tg: "MT5 حساب ممول",
    sp: "50,000$ Balance · 1-Phase",
    description_ar: "تحدي من مرحلة واحدة فقط للحصول على التمويل المباشر خلال 3 أيام تداول كحد أدنى.",
    description_en: "One-phase rapid pass evaluation with minimum 3 trading days required."
  },

  // Free Bonuses
  {
    id: "bonus_30_nodeposit",
    c: "bonus",
    ar: "بونص تداول مجاني 30$ بدون إيداع للمتداولين الجدد",
    en: "30$ No-Deposit Welcome Trading Bonus",
    p: 0,
    o: 30,
    r: 5.0,
    n: 3410,
    bs: 1,
    d: 100,
    tg: "بونص مجاني بدون إيداع",
    sp: "30$ Free · Withdrawable Profit",
    description_ar: "احصل على 30 دولاراً رصيداً حقيقياً في حساب التداول الخاص بك مباشرة بعد فتح الحساب وتأكيد الهوية. جميع الأرباح قابلة للسحب بالكامل.",
    description_en: "Claim a 30$ real trading account credit with zero initial deposit. All trading profits are withdrawable."
  },
  {
    id: "bonus_100_deposit",
    c: "bonus",
    ar: "بونص إيداع مضاعف 100% حتى 500$ لدعم الهامش",
    en: "100% Margin Deposit Match Bonus (up to 500$)",
    p: 0,
    o: 500,
    r: 4.95,
    n: 1890,
    bs: 2,
    d: 100,
    tg: "بونص مضاعفة رصيد",
    sp: "100% Match · Margin Support",
    description_ar: "ضاعف رصيدك فور الإيداع لدعم الهامش وتحمل تقلبات السوق بنسبة 100%.",
    description_en: "Double your trading margin instantly with a 100% credit bonus eligible for drawdown support."
  }
];

export const INITIAL_PAYMENT_METHODS: PaymentMethod[] = [
  {
    id: "usdt",
    on: true,
    currency: "USD",
    ar: "USDT (شبكة BEP20)",
    en: "USDT (BEP20)",
    icon: "usdt",
    color: "#26A17B",
    acc: "0x89c44569e5d4cb0d829ebdf28f8f2b3e4f738a19",
    da: "أرسل المبلغ بعملة USDT عبر شبكة BNB Smart Chain (BEP20) إلى العنوان أعلاه فقط، ثم اضغط «تم الدفع».",
    de: "Send USDT on BNB Smart Chain (BEP20) network to the address above, then tap “I have paid”."
  },
  {
    id: "binance",
    on: true,
    currency: "USD",
    ar: "Binance Pay (معرف بينانس)",
    en: "Binance Pay",
    icon: "binance",
    color: "#F0B90B",
    acc: "482910482",
    da: "ادفع عبر تطبيق Binance Pay بدون رسوم باستخدام الـ Pay ID أعلاه، ثم اضغط «تم الدفع».",
    de: "Pay with zero fees via Binance Pay using the Pay ID above, then tap “I have paid”."
  },
  {
    id: "syriatel",
    on: true,
    currency: "SYP",
    ar: "سيرياتيل كاش (Syriatel Cash)",
    en: "Syriatel Cash",
    icon: "phone",
    color: "#E30613",
    acc: "0991234567",
    da: "حوّل المبلغ بالليرة السورية إلى رقم محفظة سيرياتيل كاش أعلاه، وأرفق إشعار التحويل ثم اضغط «تم الدفع».",
    de: "Transfer the amount in SYP to the Syriatel Cash wallet above, attach receipt then tap “I have paid”."
  },
  {
    id: "sham",
    on: true,
    currency: "SYP",
    ar: "شام كاش (Sham Cash)",
    en: "Sham Cash",
    icon: "wallet",
    color: "#0B7A4B",
    acc: "0933987654",
    da: "حوّل المبلغ عبر خدمة شام كاش إلى رقم الحساب أعلاه ثم اضغط «تم الدفع».",
    de: "Transfer via Sham Cash to the account number above then tap “I have paid”."
  }
];

export const INITIAL_PARTNER: PartnerConfig = {
  on: true,
  name: "Utoppick",
  url: "https://www.utoppick.com/register?ref=742221",
  ar: "أنشئ متجرك الإلكتروني الاحترافي مع شريكنا الرسمي Utoppick",
  en: "Build your professional online store with our official partner Utoppick",
  ba: "سجّل الآن في Utoppick",
  be: "Sign up on Utoppick",
  banner_bg_url: ""
};

export const INITIAL_COUPONS: Coupon[] = [
  { code: "AMX10", discountPercent: 10 },
  { code: "WELCOME", discountPercent: 15, minSpend: 20 },
  { code: "VIP007", discountAmount: 25, minSpend: 100 }
];

export const EXCHANGE_RATES = {
  USD: { rate: 1, symbol: "USDT" },
  SYP: { rate: 140, symbol: "ل.س" }
};
